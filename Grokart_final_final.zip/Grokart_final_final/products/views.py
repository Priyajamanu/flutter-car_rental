from django.shortcuts import render, get_object_or_404,redirect
from .models import Product, Category
from PIL import Image

def filtered_products(request, category_slug):
    categories = Category.objects.all()
    products = Product.objects.all()
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        products = products.filter(category=category)
    print(category, products)
    template = "products/categories/filter.html"
    context = {"categories": categories, "product_query_set": products, "category": category}
    return render(request, template, context)


def main_products(request):
    products = Product.objects.all()
    return render(request, "products/main_products.html", {"products": products})


def categories(request):
    categories = Category.objects.all()
    return render(request, "products/categories.html", {"categories": categories})

def add_cat(request):
    if request.method=='POST':
        print(request.POST)
        cat=request.POST.get("category")
        thumb=request.POST.get("thumb")

        # thumb=thumb.resize((140,140), Image.ANTIALIAS)

        data=Category(name=cat,slug=cat,thumbnail=thumb)
        data.save()
        return redirect('/products/addcat')
    return render(request,"products/add_cat.html")

def add_pro(request):
    if request.method=='POST':
        print(request.POST)
        temp=request.POST.get("category")
        cat=Category.objects.get(name=temp)
        name=request.POST.get("name")
        slug=request.POST.get("slug")
        url_morrisons=request.POST.get("url_morrisons")
        url_sainsburys=request.POST.get("url_sainsburys")
        url_tesco=request.POST.get("url_tesco")
        price_morrisons=request.POST.get("price_morrisons")
        price_sainsburys=request.POST.get("price_sainsburys")
        price_tesco=request.POST.get("price_tesco")
        thumb=request.POST.get("thumb")
        
        # thumb=thumb.resize((140,140), Image.ANTIALIAS)

        data=Product(category=cat,name=name,slug=slug,url_morrisons=url_morrisons,url_sainsburys=url_sainsburys,url_tesco=url_tesco,price_morrisons=price_morrisons,price_sainsburys=price_sainsburys,price_tesco=price_tesco,thumbnail=thumb)
        data.save()
        return redirect('/products/addpro')
    return render(request,"products/add_pro.html")