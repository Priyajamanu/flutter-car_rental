from django.urls import path, re_path
from . import views

app_name = "products"

urlpatterns = [
    path('main/', views.main_products, name="main"),
    path('categories/', views.categories, name="categories"),
    path('addcat/',views.add_cat,name="add_cat"),
    path('addpro/',views.add_pro,name="add_pro"),
    re_path(r'categories/(?P<category_slug>[-\w]+)/', views.filtered_products, name="filtered_products"),
]
