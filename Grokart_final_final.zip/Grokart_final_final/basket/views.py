from django.shortcuts import render, HttpResponseRedirect

# Create your views here.
from products.models import Product,Category

from .models import Basket, BasketItem
import pandas as pd
import numpy as np
from mlxtend.preprocessing import TransactionEncoder 
from mlxtend.frequent_patterns import apriori
from mlxtend import frequent_patterns
from mlxtend.frequent_patterns import association_rules
def basket_view(request):
    try:
        session_id = request.session["basket_id"]
    except KeyError:
        session_id = None

    if session_id:
        basket = Basket.objects.get(id=session_id)
        # print(basket)
        # for item in basket:
        #     print(item.category)
        # data=pd.read_csv('static/GroceryStoreDataSet (1).csv')
        store=pd.read_csv('static/GroceryStoreDataSet (1).csv',names=['product'],header=None)
        store=list(store['product'].apply(lambda x: x.split(",")))
        te=TransactionEncoder()
        store_ap=te.fit(store).transform(store)
        store_ap=pd.DataFrame(store_ap,columns=te.columns_)
        frequent_item=apriori(store_ap,min_support=0.15,use_colnames=True)
        store_association=association_rules(frequent_item,metric="lift",min_threshold=0.8)
        store_association_new=store_association[['antecedents', 'consequents', 'antecedent support',
       'consequent support', 'support', 'confidence', 'lift']]
        store_association_new["antecedents"] = store_association_new["antecedents"].apply(lambda x: list(x)[0]).astype("unicode")
        store_association_new["consequents"] = store_association_new["consequents"].apply(lambda x: list(x)[0]).astype("unicode")
        cat=[]
        r=[]

        for item in basket.basketitem_set.all():
            cat.append(item.product.category)
            # print(item.product.category)
        catset=set(cat)
        print(catset)
        for c in catset:
            datatemp=store_association_new[store_association_new['antecedents'] ==c.name]
            datatemp.sort_values(by=['lift'],ascending=False)
            for i in range(0,len(datatemp.index)):
                if datatemp['lift'].iloc[i]>1:
                    r.append(datatemp['consequents'].iloc[i])
        rcat=set(r)
        print(rcat)
        recom=Product.objects.none()
        for i in rcat:
            ctemp=Category.objects.get(name=i)
            recom=Product.objects.filter(category=ctemp)
        # print(recom)
        context = {"basket": basket,"recom":recom}
    else:
        empty_message = "Your basket is currently empty"
        context = {"empty": True, "empty_message": empty_message}

    template = "basket/basket-view.html"
    return render(request, template, context)


def update_basket(request, slug):
    # session expires after x seconds of inactivity
    request.session.set_expiry(1800)
    try:
        quantity = request.GET.get("quantity")
        update_quantity = True
    except ValueError:
        quantity = None
        update_quantity = False

    # Get if cart exists. if not create a new one.
    try:
        session_id = request.session["basket_id"]
    except KeyError:
        new_basket = Basket()
        new_basket.save()
        request.session["basket_id"] = new_basket.id
        session_id = new_basket.id

    basket = Basket.objects.get(id=session_id)

    try:
        product = Product.objects.get(slug=slug)
    except Product.DoesNotExist:
        pass

    # the below returns ("Basket item object", "true/false")
    basket_item, created = BasketItem.objects.get_or_create(basket=basket, product=product)


    if quantity and update_quantity:
        if int(quantity) <= 0:
            basket_item.delete()
        else:
            basket_item.quantity = quantity
            basket_item.save()
    else:
        pass

    start_total_tesco = 0.00
    start_total_sainsburys = 0.00
    start_total_morrisons = 0.00

    for item in basket.basketitem_set.all():
        product_total_tesco = float(item.product.price_tesco) * item.quantity
        product_total_sainsburys = float(item.product.price_sainsburys) * item.quantity
        product_total_morrisons = float(item.product.price_morrisons) * item.quantity
        start_total_tesco += product_total_tesco
        start_total_sainsburys += product_total_sainsburys
        start_total_morrisons += product_total_morrisons

    request.session["items_total"] = basket.basketitem_set.count()
    # print(basket.basketitem_set.count())

    basket.total_tesco = start_total_tesco
    basket.total_sainsburys = start_total_sainsburys
    basket.total_morrisons = start_total_morrisons

    basket.save()
    return HttpResponseRedirect(request.META.get("HTTP_REFERER"))
